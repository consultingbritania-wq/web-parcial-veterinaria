import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistroMascotaComponent } from './pages/registro-mascota/registro-mascota.component';
import { HistorialMascotasComponent } from './pages/historial-mascotas/historial-mascotas.component';

const routes: Routes = [
  {
    path: 'registro',
    component: RegistroMascotaComponent
  },
  {
    path: 'historial',
    component: HistorialMascotasComponent
  },
  {
    path: '',
    redirectTo: 'registro',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MascotasRoutingModule {}
