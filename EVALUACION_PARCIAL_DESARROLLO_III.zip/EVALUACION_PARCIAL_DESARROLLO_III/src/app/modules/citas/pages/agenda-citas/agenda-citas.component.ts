import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CitasService } from '../../../../core/services/citas.service';
import { MascotasService } from '../../../../core/services/mascotas.service';
import { NotificationService } from '../../../../core/services/notification.service';
import { Cita, EstadoCita, PrioridadCita, ICita } from '../../../../models/cita.model';
import { Mascota } from '../../../../models/mascota.model';
import { Dueno } from '../../../../models/dueno.model';

@Component({
  selector: 'app-agenda-citas',
  templateUrl: './agenda-citas.component.html',
  styleUrls: ['./agenda-citas.component.scss'],
  standalone: false
})
export class AgendaCitasComponent implements OnInit {
  public todasLasCitas: Cita[] = [];
  public mascotas: Mascota[] = [];
  public duenos: Dueno[] = [];
  public fechaSeleccionada: Date = new Date();
  public modalAgendarAbierto: boolean = false;

  public filtroEstado: string = 'TODOS';
  public filtroPrioridad: string = 'TODOS';

  constructor(
    private citasService: CitasService,
    private mascotasService: MascotasService,
    private notificationService: NotificationService,
    private router: Router
  ) {}

  public ngOnInit(): void {
    this.cargarDatos();
  }

  public get citasFiltradas(): Cita[] {
    return this.todasLasCitas.filter(cita => {
      const coincideEstado = this.filtroEstado === 'TODOS' || cita.estado === this.filtroEstado;
      const coincidePrioridad = this.filtroPrioridad === 'TODOS' || cita.prioridad === this.filtroPrioridad;
      return coincideEstado && coincidePrioridad;
    });
  }

  public get totalUrgencias(): number {
    return this.todasLasCitas.filter(c => c.prioridad === 'URGENCIA' && c.estado === 'PROGRAMADA').length;
  }

  public get totalEnAtencion(): number {
    return this.todasLasCitas.filter(c => c.estado === 'EN_ATENCION').length;
  }

  public get totalProgramadas(): number {
    return this.todasLasCitas.filter(c => c.estado === 'PROGRAMADA').length;
  }

  public alSeleccionarFecha(fecha: Date): void {
    this.fechaSeleccionada = fecha;
  }

  public abrirModalAgendar(): void {
    if (this.mascotas.length === 0) {
      this.notificationService.mostrarAdvertencia(
        'Debe registrar al menos un paciente antes de poder agendar citas médicas.'
      );
      this.router.navigate(['/mascotas/registro']);
      return;
    }
    this.modalAgendarAbierto = true;
  }

  public cerrarModalAgendar(): void {
    this.modalAgendarAbierto = false;
  }

  public procesarGuardarCita(datosCita: Partial<ICita>): void {
    this.citasService.agendarCita(datosCita).subscribe({
      next: (citaCreada) => {
        this.notificationService.mostrarExito(
          `Cita agendada con éxito para ${citaCreada.mascotaNombre} el ${new Date(citaCreada.fechaHora).toLocaleDateString()}.`
        );
        this.modalAgendarAbierto = false;
        this.cargarCitas();
      },
      error: () => {
        this.notificationService.mostrarError('Error al programar la cita médica.');
      }
    });
  }

  public alCambiarEstado(evento: { id: string; nuevoEstado: EstadoCita }): void {
    this.citasService.cambiarEstadoCita(evento.id, evento.nuevoEstado).subscribe({
      next: (citaModificada) => {
        this.notificationService.mostrarInfo(
          `Estado de la cita para ${citaModificada.mascotaNombre} cambiado a: ${citaModificada.estado}.`
        );
        this.cargarCitas();
      },
      error: (err) => {
        this.notificationService.mostrarError(err.message || 'Error al actualizar estado.');
      }
    });
  }

  public navegarAHistorial(mascotaId: string): void {
    this.router.navigate(['/mascotas/historial'], {
      queryParams: { mascotaId }
    });
  }

  private cargarDatos(): void {
    this.cargarCitas();
    this.mascotasService.obtenerMascotas().subscribe(m => this.mascotas = m);
    this.mascotasService.obtenerDuenos().subscribe(d => this.duenos = d);
  }

  private cargarCitas(): void {
    this.citasService.obtenerCitas().subscribe(citas => {
      this.todasLasCitas = citas;
    });
  }
}
