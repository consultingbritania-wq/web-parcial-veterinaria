import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Mascota } from '../../../../models/mascota.model';
import { Dueno } from '../../../../models/dueno.model';
import { ICita, MotivoConsulta, PrioridadCita } from '../../../../models/cita.model';
import { ClinicaValidators } from '../../../../shared/validators/clinica-validators';

@Component({
  selector: 'app-formulario-cita',
  templateUrl: './formulario-cita.component.html',
  styleUrls: ['./formulario-cita.component.scss'],
  standalone: false
})
export class FormularioCitaComponent implements OnInit {
  @Input() mascotas: Mascota[] = [];
  @Input() duenos: Dueno[] = [];
  @Input() fechaSugerida: Date = new Date();
  @Input() horariosDisponibles: string[] = [
    '08:30', '09:00', '09:30', '10:00', '10:30',
    '11:00', '11:30', '14:00', '14:30', '15:00',
    '15:30', '16:00', '16:30', '17:00', '17:30'
  ];

  @Output() guardarCita = new EventEmitter<Partial<ICita>>();
  @Output() cancelar = new EventEmitter<void>();

  public formularioCita!: FormGroup;
  public motivosDisponibles: MotivoConsulta[] = [
    'CONTROL_RUTINA',
    'VACUNACION',
    'DESPARASITACION',
    'CIRUGIA',
    'URGENCIA_MEDICA',
    'DERMATOLOGIA',
    'ODONTOLOGIA'
  ];
  public prioridadesDisponibles: PrioridadCita[] = ['BAJA', 'MEDIA', 'ALTA', 'URGENCIA'];

  constructor(private fb: FormBuilder) {}

  public ngOnInit(): void {
    this.construirFormulario();
  }

  public onCambioMascota(mascotaId: string): void {
    const mascota = this.mascotas.find(m => m.id === mascotaId);
    if (mascota) {
      const dueno = this.duenos.find(d => d.id === mascota.duenoId);
      this.formularioCita.patchValue({
        duenoId: mascota.duenoId,
        duenoNombre: dueno ? dueno.nombreCompleto : 'Propietario Registrado',
        mascotaNombre: mascota.nombre
      });
    }
  }

  public emitirGuardado(): void {
    if (this.formularioCita.invalid) {
      this.formularioCita.markAllAsTouched();
      return;
    }

    const valor = this.formularioCita.value;
    const [horas, minutos] = valor.hora.split(':');
    const fechaCompleta = new Date(valor.fecha);
    fechaCompleta.setHours(Number(horas), Number(minutos), 0, 0);

    const payload: Partial<ICita> = {
      mascotaId: valor.mascotaId,
      mascotaNombre: valor.mascotaNombre,
      duenoId: valor.duenoId,
      duenoNombre: valor.duenoNombre,
      veterinarioId: valor.veterinarioId || 'VET-001',
      veterinarioNombre: 'Dr. Alejandro Morales',
      fechaHora: fechaCompleta,
      motivo: valor.motivo,
      descripcionSintomas: valor.descripcionSintomas,
      prioridad: valor.prioridad,
      costoEstimado: Number(valor.costoEstimado) || 50,
      duracionMinutos: Number(valor.duracionMinutos) || 30
    };

    this.guardarCita.emit(payload);
  }

  public emitirCancelacion(): void {
    this.cancelar.emit();
  }

  private construirFormulario(): void {
    const anio = this.fechaSugerida.getFullYear();
    const mes = (this.fechaSugerida.getMonth() + 1).toString().padStart(2, '0');
    const dia = this.fechaSugerida.getDate().toString().padStart(2, '0');
    const fechaIso = `${anio}-${mes}-${dia}`;

    this.formularioCita = this.fb.group({
      mascotaId: ['', [Validators.required]],
      mascotaNombre: [''],
      duenoId: [''],
      duenoNombre: [''],
      fecha: [fechaIso, [Validators.required]],
      hora: ['09:00', [Validators.required]],
      motivo: ['CONTROL_RUTINA', [Validators.required]],
      prioridad: ['MEDIA', [Validators.required]],
      descripcionSintomas: ['', [Validators.required, Validators.minLength(5)]],
      costoEstimado: [60, [Validators.required, Validators.min(0)]],
      duracionMinutos: [30, [Validators.required, Validators.min(15)]]
    });

    if (this.mascotas.length > 0) {
      this.formularioCita.patchValue({ mascotaId: this.mascotas[0].id });
      this.onCambioMascota(this.mascotas[0].id);
    }
  }
}
