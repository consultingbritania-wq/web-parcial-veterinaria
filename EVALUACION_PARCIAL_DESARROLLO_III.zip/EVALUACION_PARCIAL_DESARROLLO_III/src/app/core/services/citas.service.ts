import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { map } from 'rxjs/operators';
import { Cita, ICita, EstadoCita, PrioridadCita, MotivoConsulta } from '../../models/cita.model';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class CitasService {
  private readonly STORAGE_CITAS = 'clinica_citas_db';
  private citasSubject: BehaviorSubject<Cita[]>;
  public citas$: Observable<Cita[]>;

  constructor(private storageService: StorageService) {
    const citasIniciales = this.cargarCitasIniciales();
    this.citasSubject = new BehaviorSubject<Cita[]>(citasIniciales);
    this.citas$ = this.citasSubject.asObservable();
  }

  public obtenerCitas(): Observable<Cita[]> {
    return this.citas$;
  }

  public obtenerCitasPorFecha(fecha: Date): Observable<Cita[]> {
    return this.citas$.pipe(
      map(citas => citas.filter(c => {
        const fechaCita = new Date(c.fechaHora);
        return fechaCita.getFullYear() === fecha.getFullYear() &&
               fechaCita.getMonth() === fecha.getMonth() &&
               fechaCita.getDate() === fecha.getDate();
      }))
    );
  }

  public obtenerCitasPorMascota(mascotaId: string): Observable<Cita[]> {
    return this.citas$.pipe(
      map(citas => citas.filter(c => c.mascotaId === mascotaId))
    );
  }

  public agendarCita(datosCita: Partial<ICita>): Observable<Cita> {
    const nuevaCita = new Cita(
      'CIT-' + Date.now(),
      datosCita.mascotaId || '',
      datosCita.duenoId || '',
      datosCita.veterinarioId || 'VET-001',
      datosCita.fechaHora ? new Date(datosCita.fechaHora) : new Date(),
      datosCita.motivo || 'CONTROL_RUTINA',
      datosCita.descripcionSintomas || '',
      datosCita.prioridad || 'MEDIA',
      Number(datosCita.costoEstimado) || 50,
      Number(datosCita.duracionMinutos) || 30,
      'PROGRAMADA',
      datosCita.mascotaNombre,
      datosCita.duenoNombre,
      datosCita.veterinarioNombre || 'Dr. Alejandro Morales'
    );

    const citasActuales = [...this.citasSubject.value, nuevaCita];
    this.actualizarStorage(citasActuales);
    return of(nuevaCita);
  }

  public cambiarEstadoCita(id: string, nuevoEstado: EstadoCita): Observable<Cita> {
    const citas = this.citasSubject.value;
    const cita = citas.find(c => c.id === id);
    if (!cita) {
      return throwError(() => new Error('Cita no encontrada'));
    }

    cita.transicionarA(nuevoEstado);
    const listaActualizada = [...citas];
    this.actualizarStorage(listaActualizada);
    return of(cita);
  }

  public obtenerHorariosDisponibles(fecha: Date): Observable<string[]> {
    const horariosBase = [
      '08:00', '08:30', '09:00', '09:30', '10:00', '10:30',
      '11:00', '11:30', '14:00', '14:30', '15:00', '15:30',
      '16:00', '16:30', '17:00', '17:30', '18:00'
    ];

    return this.obtenerCitasPorFecha(fecha).pipe(
      map(citasDelDia => {
        const horasOcupadas = citasDelDia
          .filter(c => c.estado !== 'CANCELADA')
          .map(c => {
            const d = new Date(c.fechaHora);
            const hora = d.getHours().toString().padStart(2, '0');
            const minutos = d.getMinutes().toString().padStart(2, '0');
            return `${hora}:${minutos}`;
          });

        return horariosBase.filter(h => !horasOcupadas.includes(h));
      })
    );
  }

  private actualizarStorage(lista: Cita[]): void {
    this.citasSubject.next(lista);
    const dto = lista.map(c => ({
      id: c.id,
      mascotaId: c.mascotaId,
      mascotaNombre: c.mascotaNombre,
      duenoId: c.duenoId,
      duenoNombre: c.duenoNombre,
      veterinarioId: c.veterinarioId,
      veterinarioNombre: c.veterinarioNombre,
      fechaHora: c.fechaHora,
      motivo: c.motivo,
      descripcionSintomas: c.descripcionSintomas,
      estado: c.estado,
      prioridad: c.prioridad,
      costoEstimado: c.costoEstimado,
      duracionMinutos: c.duracionMinutos,
      notasVeterinario: c.notasVeterinario,
      fechaCreacion: c.fechaCreacion,
      fechaActualizacion: c.fechaActualizacion
    }));
    this.storageService.guardar(this.STORAGE_CITAS, dto);
  }

  private cargarCitasIniciales(): Cita[] {
    const guardadas = this.storageService.obtener<ICita[]>(this.STORAGE_CITAS);
    if (guardadas && guardadas.length > 0) {
      return guardadas.map(c => Cita.desdeObjeto(c));
    }

    const hoy = new Date();
    const hoyHora10 = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate(), 10, 0);
    const hoyHora14 = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate(), 14, 30);
    const mananaHora9 = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() + 1, 9, 0);
    const mananaHora16 = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() + 1, 16, 0);

    return [
      new Cita(
        'CIT-101',
        'MAS-003',
        'DUE-003',
        'VET-001',
        hoyHora10,
        'URGENCIA_MEDICA',
        'Dificultad respiratoria aguda tras paseo y jadeo excesivo.',
        'URGENCIA',
        120,
        45,
        'PROGRAMADA',
        'Bruno',
        'Mateo Vargas Llosa',
        'Dr. Alejandro Morales'
      ),
      new Cita(
        'CIT-102',
        'MAS-001',
        'DUE-001',
        'VET-001',
        hoyHora14,
        'CONTROL_RUTINA',
        'Revisión traumatológica y seguimiento de medicación para displasia.',
        'MEDIA',
        60,
        30,
        'PROGRAMADA',
        'Thor',
        'Carlos Ramírez Mendoza',
        'Dr. Alejandro Morales'
      ),
      new Cita(
        'CIT-103',
        'MAS-002',
        'DUE-002',
        'VET-002',
        mananaHora9,
        'VACUNACION',
        'Vacuna triple felina anual y chequeo general.',
        'BAJA',
        45,
        30,
        'PROGRAMADA',
        'Michi',
        'Lucía Fernández Soto',
        'Dra. Mariana Castillo'
      ),
      new Cita(
        'CIT-104',
        'MAS-001',
        'DUE-001',
        'VET-001',
        mananaHora16,
        'ODONTOLOGIA',
        'Evaluación de acumulación de sarro en molares superiores.',
        'ALTA',
        85,
        40,
        'PROGRAMADA',
        'Thor',
        'Carlos Ramírez Mendoza',
        'Dr. Alejandro Morales'
      )
    ];
  }
}
