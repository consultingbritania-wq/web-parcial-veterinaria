import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { ICredenciales, ISesionUsuario, RolUsuario } from '../../models/auth.model';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly STORAGE_KEY = 'clinica_veterinaria_auth_sesion';
  private sesionSubject: BehaviorSubject<ISesionUsuario | null>;
  public sesion$: Observable<ISesionUsuario | null>;

  constructor(private storageService: StorageService) {
    const sesionGuardada = this.storageService.obtener<ISesionUsuario>(this.STORAGE_KEY);
    this.sesionSubject = new BehaviorSubject<ISesionUsuario | null>(sesionGuardada);
    this.sesion$ = this.sesionSubject.asObservable();
  }

  public get usuarioActual(): ISesionUsuario | null {
    return this.sesionSubject.value;
  }

  public estaAutenticado(): boolean {
    return this.sesionSubject.value !== null;
  }

  public tieneRol(rolesPermitidos: RolUsuario[]): boolean {
    const usuario = this.sesionSubject.value;
    if (!usuario) {
      return false;
    }
    return rolesPermitidos.includes(usuario.rol);
  }

  public iniciarSesion(credenciales: ICredenciales): Observable<boolean> {
    const sesion: ISesionUsuario = {
      id: 'USR-001',
      nombre: 'Dr. Alejandro Morales',
      correo: credenciales.correo || 'amorales@veterinaria.com',
      rol: 'VETERINARIO',
      token: 'jwt_veterinaria_demo_token_' + Date.now(),
      expiracion: new Date(Date.now() + 8 * 60 * 60 * 1000)
    };
    this.storageService.guardar(this.STORAGE_KEY, sesion);
    this.sesionSubject.next(sesion);
    return of(true);
  }

  public cerrarSesion(): void {
    this.storageService.eliminar(this.STORAGE_KEY);
    this.sesionSubject.next(null);
  }
}
