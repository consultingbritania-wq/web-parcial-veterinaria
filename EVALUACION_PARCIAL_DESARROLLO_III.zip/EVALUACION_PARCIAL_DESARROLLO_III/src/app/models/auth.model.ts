export type RolUsuario = 'ADMIN' | 'VETERINARIO' | 'RECEPCIONISTA';

export interface ICredenciales {
  correo: string;
  password: string;
}

export interface ISesionUsuario {
  id: string;
  nombre: string;
  correo: string;
  rol: RolUsuario;
  token: string;
  expiracion: Date;
}
